# jp-landing-mvp

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Real Reddit Data (No backend)

Best method (always works):
1. Open a Reddit post URL in your browser.
2. Add `.json` to the end of the URL (or use the "comments" URL and append `.json`).
3. Copy the JSON response and paste it into the app in "Paste Reddit JSON".

Note: Direct URL fetch from the browser may fail due to Reddit CORS policies. The app handles this safely and will not crash.
