import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Menu,
  X,
  CheckCircle,
  Zap,
  Workflow,
  Send,
  Users,
  Clock,
  DollarSign,
  TrendingUp,
  MessageSquare,
  Database,
  GitBranch,
  BarChart3,
  FileCheck,
  CheckCheck,
  Play,
  ArrowRight,
} from "lucide-react";

type NotifType = "info" | "success" | "error";
type Notif = { id: string; message: string; type: NotifType };

type ChatMsgType = "system" | "user" | "bot";
type ChatMsg = { type: ChatMsgType; text: string; time: string };

type RedditParsed = {
  title: string;
  subreddit: string;
  author: string;
  createdISO: string;
  score: number;
  numComments: number;
  permalink?: string;
  selftext?: string;
};

function uid(): string {
  // crypto.randomUUID() is widely available; fallback avoids runtime errors.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c = (globalThis as any).crypto;
  return typeof c?.randomUUID === "function"
    ? c.randomUUID()
    : String(Date.now()) + Math.random().toString(16).slice(2);
}

function fmtTime(): string {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function parseRedditJson(input: unknown): RedditParsed {
  const fail = (m: string) => {
    throw new Error(m);
  };

  if (!input || (typeof input !== "object" && !Array.isArray(input))) {
    fail("Invalid JSON: expected an object/array.");
  }

  if (Array.isArray(input)) {
    const postListing = input[0] as any;
    const postChild = postListing?.data?.children?.[0]?.data;
    if (!postChild) fail("Could not find post data in listing array.");

    const createdUtc = Number(postChild.created_utc ?? 0);
    const createdISO = createdUtc ? new Date(createdUtc * 1000).toISOString() : new Date().toISOString();

    return {
      title: String(postChild.title ?? "Untitled"),
      subreddit: String(postChild.subreddit ?? "unknown"),
      author: String(postChild.author ?? "unknown"),
      createdISO,
      score: Number(postChild.score ?? 0),
      numComments: Number(postChild.num_comments ?? 0),
      permalink: postChild.permalink ? String(postChild.permalink) : undefined,
      selftext: postChild.selftext ? String(postChild.selftext) : undefined,
    };
  }

  const obj = input as any;
  const createdUtc = Number(obj.created_utc ?? obj?.data?.created_utc ?? 0);
  const createdISO = createdUtc ? new Date(createdUtc * 1000).toISOString() : new Date().toISOString();
  const title = obj.title ?? obj?.data?.title;
  const subreddit = obj.subreddit ?? obj?.data?.subreddit;
  const author = obj.author ?? obj?.data?.author;

  if (!title || !subreddit) fail("Unrecognized Reddit JSON shape. Paste the full reddit JSON response.");

  return {
    title: String(title),
    subreddit: String(subreddit),
    author: String(author ?? "unknown"),
    createdISO,
    score: Number(obj.score ?? obj?.data?.score ?? 0),
    numComments: Number(obj.num_comments ?? obj?.data?.num_comments ?? 0),
    permalink: obj.permalink ?? obj?.data?.permalink,
    selftext: obj.selftext ?? obj?.data?.selftext,
  };
}

async function tryFetchRedditJson(redditUrl: string): Promise<unknown> {
  const url = redditUrl.trim();
  if (!url) throw new Error("URL is empty.");

  const hasJson = url.includes(".json");
  const fetchUrl = hasJson ? url : url.replace(/\/+$/, "") + ".json?raw_json=1";

  const res = await fetch(fetchUrl, {
    method: "GET",
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`Fetch failed: HTTP ${res.status}`);
  }
  return await res.json();
}

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  const [notifications, setNotifications] = useState<Notif[]>([]);
  const [simulationRunning, setSimulationRunning] = useState(false);
  const [liveSimulation, setLiveSimulation] = useState(0);

  const [messageInput, setMessageInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([
    { type: "system", text: "System ready. Send a message or load a Reddit post JSON.", time: "Now" },
  ]);

  const [redditUrl, setRedditUrl] = useState("");
  const [redditJsonText, setRedditJsonText] = useState("");
  const [redditParsed, setRedditParsed] = useState<RedditParsed | null>(null);

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const addNotification = (message: string, type: NotifType = "info") => {
    const id = uid();
    setNotifications((prev) => [...prev, { id, message, type }]);
    window.setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 3500);
  };

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Simulation progression (6 steps total)
  const ontologyLen = 6;
  useEffect(() => {
    if (!simulationRunning) return;
    if (liveSimulation >= ontologyLen) return;

    const t = window.setTimeout(() => setLiveSimulation((n) => n + 1), 1400);
    return () => window.clearTimeout(t);
  }, [simulationRunning, liveSimulation]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages.length]);

  const baseStats = useMemo(
    () => [
      {
        label: "Leads Captured",
        value: redditParsed ? String(Math.max(1, redditParsed.numComments)) : "47",
        change: redditParsed ? "Live" : "+23%",
        icon: Users,
        color: "#55A843",
      },
      { label: "Avg Response Time", value: "2.3m", change: "-15%", icon: Clock, color: "#2C77C4" },
      { label: "Revenue", value: redditParsed ? "$—" : "$18.2K", change: redditParsed ? "Depends" : "+34%", icon: DollarSign, color: "#1C5A31" },
      { label: "Conversion Rate", value: redditParsed ? "—" : "68%", change: redditParsed ? "Depends" : "+12%", icon: TrendingUp, color: "#55A843" },
    ],
    [redditParsed]
  );

  const ontologySteps = useMemo(() => {
    const channel = redditParsed ? "Reddit" : "Instagram";
    const message = redditParsed ? redditParsed.title : "I need help with lead automation";
    const ts = redditParsed ? new Date(redditParsed.createdISO).toLocaleString() : "10:47 AM";
    const category = redditParsed ? `r/${redditParsed.subreddit}` : "Lead Automation";

    return [
      {
        num: 1,
        name: "CAPTURE",
        desc: redditParsed ? "Post ingested from Reddit JSON" : "Message received from source",
        data: { channel, message, timestamp: ts },
        icon: MessageSquare,
        color: "#55A843",
      },
      {
        num: 2,
        name: "CLASSIFY",
        desc: "Tags intent & priority (rule-based MVP)",
        data: {
          intent: redditParsed ? "Inbound inquiry (thread)" : "Consultation",
          priority: redditParsed && redditParsed.score > 50 ? "High" : "Normal",
          category,
        },
        icon: Database,
        color: "#2C77C4",
      },
      {
        num: 3,
        name: "ROUTE",
        desc: "Creates ticket + assigns owner",
        data: {
          ticket: "#" + String(1800 + (redditParsed ? (redditParsed.score % 200) : 47)),
          assignedTo: "Owner",
          system: "CRM/Inbox",
        },
        icon: GitBranch,
        color: "#1C5A31",
      },
      {
        num: 4,
        name: "RESPOND",
        desc: "Generates next action + reply draft",
        data: {
          action: "Offer booking link",
          template: "Discovery",
          eta: "< 10 min",
        },
        icon: Send,
        color: "#55A843",
      },
      {
        num: 5,
        name: "TRACK",
        desc: "Logs metadata + pipeline stage",
        data: {
          source: channel,
          score: redditParsed ? String(redditParsed.score) : "—",
          stage: "New",
        },
        icon: BarChart3,
        color: "#2C77C4",
      },
      {
        num: 6,
        name: "PROVE",
        desc: "Evidence record generated (MVP metadata only)",
        data: {
          record: "Created",
          hash: "SHA-256 (later)",
          export: "PDF/A (later)",
        },
        icon: FileCheck,
        color: "#1C5A31",
      },
    ];
  }, [redditParsed]);

  const startSimulation = () => {
    setSimulationRunning(true);
    setLiveSimulation(0);
    addNotification("Running 6-step pipeline…", "success");
  };

  const stopAndResetSimulation = () => {
    setSimulationRunning(false);
    setLiveSimulation(0);
    addNotification("Simulation reset.", "info");
  };

  const handleSendMessage = () => {
    const text = messageInput.trim();
    if (!text) return;

    setChatMessages((prev) => [...prev, { type: "user", text, time: fmtTime() }]);

    const schedule: Array<{ delay: number; msg: ChatMsg }> = [
      { delay: 350, msg: { type: "system", text: "Captured.", time: fmtTime() } },
      { delay: 900, msg: { type: "system", text: "Classified: consultation / inbound.", time: fmtTime() } },
      { delay: 1500, msg: { type: "system", text: "Routed: ticket created.", time: fmtTime() } },
      { delay: 2100, msg: { type: "bot", text: "Got it. Want a 15-minute intro link?", time: fmtTime() } },
    ];

    schedule.forEach((s) => {
      window.setTimeout(() => {
        setChatMessages((prev) => [...prev, s.msg]);
      }, s.delay);
    });

    addNotification("Message processed.", "success");
    setMessageInput("");
  };

  const loadRedditFromPastedJson = () => {
    try {
      const parsed = JSON.parse(redditJsonText);
      const rp = parseRedditJson(parsed);
      setRedditParsed(rp);

      setChatMessages((prev) => [
        ...prev,
        { type: "system", text: `Loaded Reddit post: "${rp.title}" (r/${rp.subreddit})`, time: fmtTime() },
      ]);

      addNotification("Reddit JSON loaded.", "success");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Invalid JSON.";
      addNotification(msg, "error");
    }
  };

  const loadRedditFromUrl = async () => {
    try {
      addNotification("Fetching Reddit URL…", "info");
      const json = await tryFetchRedditJson(redditUrl);
      const rp = parseRedditJson(json);
      setRedditParsed(rp);

      setChatMessages((prev) => [
        ...prev,
        { type: "system", text: `Loaded Reddit post from URL: "${rp.title}" (r/${rp.subreddit})`, time: fmtTime() },
      ]);

      addNotification("Reddit URL loaded.", "success");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Fetch failed.";
      addNotification(`URL fetch failed (${msg}). Paste JSON instead.`, "error");
    }
  };

  const navBg = scrollY > 50 ? "bg-[#2D2D2D]/98 shadow-xl" : "bg-[#2D2D2D]/95";

  // Active step index for UI highlight:
  // liveSimulation increments 1..6 while running; translate to 0..5
  const activeIndex = simulationRunning ? Math.min(Math.max(liveSimulation - 1, -1), ontologyLen - 1) : -1;

  return (
    <div className="min-h-screen bg-[#82807A]">
      {/* Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
        {notifications.map((n) => (
          <div
            key={n.id}
            className="bg-[#2D2D2D] text-white px-5 py-3 rounded-lg shadow-2xl flex items-center gap-3 animate-slide-in"
          >
            <CheckCircle className={n.type === "error" ? "text-red-400" : "text-[#55A843]"} size={18} />
            <span className="text-sm font-medium">{n.message}</span>
          </div>
        ))}
      </div>

      {/* Nav */}
      <nav className={`fixed w-full z-40 transition-all duration-300 ${navBg} backdrop-blur-lg`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-gradient-to-br from-[#55A843] to-[#1C5A31] rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">JP</span>
              </div>
              <div>
                <div className="text-white font-bold text-lg">Jeffrey Plewak</div>
                <div className="text-[#D3AE8A] text-xs font-medium">AI Systems & Lead Hubs</div>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <a href="#live-demo" className="text-white hover:text-[#55A843] transition-colors font-medium">
                Live Demo
              </a>
              <a href="#ontology" className="text-white hover:text-[#55A843] transition-colors font-medium">
                System
              </a>
              <button
                onClick={() => addNotification("Use the live demo below.", "info")}
                className="bg-gradient-to-r from-[#55A843] to-[#1C5A31] hover:shadow-xl hover:scale-[1.02] text-white px-6 py-2.5 rounded-lg transition-all font-semibold"
              >
                Book 15-min Intro
              </button>
            </div>

            <button
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden mt-4 bg-[#1B1B1B] rounded-xl p-4 flex flex-col gap-3">
              <a href="#live-demo" className="text-white" onClick={() => setMobileMenuOpen(false)}>
                Live Demo
              </a>
              <a href="#ontology" className="text-white" onClick={() => setMobileMenuOpen(false)}>
                System
              </a>
              <button
                onClick={() => addNotification("Use the live demo below.", "info")}
                className="bg-[#55A843] text-white px-4 py-2 rounded-lg font-semibold"
              >
                Book 15-min Intro
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-28 pb-10 px-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#55A843] rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#2C77C4] rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-6xl mx-auto relative text-center">
          <div className="inline-flex items-center bg-[#2D2D2D] text-[#55A843] px-4 py-2 rounded-full text-sm font-semibold mb-6 shadow-lg">
            <Zap size={16} className="mr-2" />
            Interactive MVP • No backend required
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-[#1B1B1B] mb-6 leading-tight">
            Watch leads flow through <span className="text-[#55A843]">the system</span>
          </h1>

          <p className="text-xl md:text-2xl text-[#4E3A29] mb-4 leading-relaxed max-w-4xl mx-auto">
            Capture → Classify → Route → Respond → Track → Prove.
          </p>

          <p className="text-base md:text-lg text-[#4E3A29]/90 max-w-3xl mx-auto">
            Load a real Reddit post (paste JSON) to drive the demo with real data—without CORS issues or broken builds.
          </p>
        </div>
      </section>

      {/* Live Demo */}
      <section id="live-demo" className="py-12 px-6 bg-[#2D2D2D]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">Run the MVP</h2>
            <p className="text-[#D3AE8A] text-lg">
              Send a message, or load a Reddit post JSON to drive real data through the pipeline.
            </p>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            {baseStats.map((stat, idx) => (
              <div
                key={idx}
                className="bg-[#1B1B1B] rounded-xl p-6 border-l-4 hover:scale-[1.01] transition-transform cursor-pointer"
                style={{ borderColor: stat.color }}
                onClick={() => addNotification(`${stat.label}: ${stat.value}`, "info")}
              >
                <div className="flex items-center justify-between mb-2">
                  <stat.icon size={22} style={{ color: stat.color }} />
                  <span className="text-[#55A843] text-sm font-bold">{stat.change}</span>
                </div>
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-[#D3AE8A] text-sm">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Reddit loader */}
            <div className="bg-[#82807A] rounded-2xl shadow-2xl overflow-hidden">
              <div className="bg-[#1B1B1B] px-6 py-4 flex items-center justify-between">
                <div className="text-white font-bold">Load Real Reddit Data</div>
                <div className="text-[#D3AE8A] text-xs">Best: paste JSON</div>
              </div>

              <div className="p-4 space-y-3">
                <div className="space-y-2">
                  <label className="text-xs text-[#1B1B1B] font-semibold">
                    Reddit URL (optional; may fail due to CORS)
                  </label>
                  <input
                    value={redditUrl}
                    onChange={(e) => setRedditUrl(e.target.value)}
                    placeholder="https://www.reddit.com/r/.../comments/.../"
                    className="w-full bg-[#2D2D2D] text-white px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#55A843]"
                  />
                  <button
                    onClick={() => void loadRedditFromUrl()}
                    className="w-full bg-[#1B1B1B] hover:bg-[#55A843] text-white py-2 rounded-lg font-semibold transition-colors"
                  >
                    Try Load from URL
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-[#1B1B1B] font-semibold">Paste Reddit JSON (guaranteed)</label>
                  <textarea
                    value={redditJsonText}
                    onChange={(e) => setRedditJsonText(e.target.value)}
                    placeholder='Paste the full .json response (usually an array with 2 listings)'
                    rows={8}
                    className="w-full bg-[#2D2D2D] text-white px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#55A843] font-mono text-xs"
                  />
                  <button
                    onClick={loadRedditFromPastedJson}
                    className="w-full bg-gradient-to-r from-[#55A843] to-[#1C5A31] text-white py-2 rounded-lg font-semibold hover:scale-[1.01] transition-transform"
                  >
                    Load Pasted JSON
                  </button>
                </div>

                {redditParsed && (
                  <div className="bg-[#2D2D2D] rounded-xl p-3">
                    <div className="text-white font-semibold text-sm">{redditParsed.title}</div>
                    <div className="text-[#D3AE8A] text-xs mt-1">
                      r/{redditParsed.subreddit} • u/{redditParsed.author} • score {redditParsed.score} • comments{" "}
                      {redditParsed.numComments}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Chat */}
            <div className="lg:col-span-2 bg-[#82807A] rounded-2xl shadow-2xl overflow-hidden">
              <div className="bg-[#1B1B1B] px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-[#55A843] rounded-full animate-pulse"></div>
                  <span className="text-white font-bold">Live Interaction</span>
                </div>
                <MessageSquare size={20} className="text-[#D3AE8A]" />
              </div>

              <div className="h-80 overflow-y-auto p-6 space-y-4">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[28rem] rounded-xl p-4 ${
                        msg.type === "user"
                          ? "bg-[#55A843] text-white"
                          : msg.type === "bot"
                          ? "bg-[#2D2D2D] text-white"
                          : "bg-[#1B1B1B] text-[#D3AE8A] border border-[#55A843]/40"
                      }`}
                    >
                      <div className="text-sm">{msg.text}</div>
                      <div className="text-xs opacity-70 mt-1">{msg.time}</div>
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>

              <div className="bg-[#1B1B1B] p-4">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    placeholder="Type a lead message…"
                    className="flex-1 bg-[#2D2D2D] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#55A843]"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="bg-gradient-to-r from-[#55A843] to-[#1C5A31] text-white px-6 py-3 rounded-lg font-semibold hover:scale-[1.01] transition-transform"
                    aria-label="Send message"
                  >
                    <Send size={20} />
                  </button>
                </div>

                <div className="text-[#D3AE8A] text-xs mt-2 text-center">
                  Tip: load a Reddit post JSON, then run the simulation below.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ontology */}
      <section id="ontology" className="py-16 px-6 bg-gradient-to-br from-[#82807A] to-[#A6784F]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center bg-[#2D2D2D] text-[#55A843] px-4 py-2 rounded-full text-sm font-bold mb-4">
              <Workflow size={16} className="mr-2" />
              6-Step Pipeline
            </div>

            <h2 className="text-4xl md:text-5xl font-bold text-[#1B1B1B] mb-5">Turn inbound into trackable work</h2>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={startSimulation}
                className="bg-gradient-to-r from-[#55A843] to-[#1C5A31] text-white px-8 py-3 rounded-xl font-bold hover:scale-[1.01] transition-transform inline-flex items-center justify-center"
              >
                <Play size={18} className="mr-2" />
                Run Live Simulation
              </button>

              <button
                onClick={stopAndResetSimulation}
                className="bg-[#2D2D2D] text-white px-8 py-3 rounded-xl font-bold hover:bg-[#1B1B1B] transition-colors"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ontologySteps.map((step, idx) => {
              const isActive = simulationRunning && idx === activeIndex;
              const isComplete = simulationRunning && idx < activeIndex;

              return (
                <div
                  key={idx}
                  className={`bg-[#2D2D2D] rounded-2xl p-6 transition-all duration-300 ${
                    isActive ? "ring-4 ring-[#55A843] scale-[1.01] shadow-2xl" : ""
                  } ${isComplete ? "opacity-80" : ""}`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className="w-14 h-14 rounded-xl flex items-center justify-center font-bold text-2xl text-white shadow-lg"
                      style={{ backgroundColor: step.color }}
                    >
                      {isComplete ? <CheckCheck size={28} /> : step.num}
                    </div>
                    <step.icon size={30} style={{ color: step.color }} className={isActive ? "animate-pulse" : ""} />
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2">{step.name}</h3>
                  <p className="text-[#D3AE8A] text-sm mb-4">{step.desc}</p>

                  <div className="bg-[#1B1B1B] rounded-lg p-3 space-y-2">
                    {Object.entries(step.data).map(([k, v]) => (
                      <div key={k} className="flex justify-between text-xs gap-3">
                        <span className="text-[#A6784F] capitalize">{k}:</span>
                        <span className="text-white font-semibold text-right break-words">{String(v)}</span>
                      </div>
                    ))}
                  </div>

                  {isActive && (
                    <div className="mt-4 bg-[#55A843] text-white text-center py-2 rounded-lg font-bold text-sm animate-pulse">
                      PROCESSING…
                    </div>
                  )}

                  {isComplete && (
                    <div className="mt-4 bg-[#1C5A31] text-white text-center py-2 rounded-lg font-bold text-sm">
                      COMPLETE
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {simulationRunning && liveSimulation >= ontologyLen && (
            <div className="mt-10 bg-gradient-to-r from-[#55A843] to-[#1C5A31] rounded-2xl p-8 text-center">
              <CheckCircle size={44} className="text-white mx-auto mb-4" />
              <h3 className="text-3xl font-bold text-white mb-2">Pipeline Complete</h3>
              <p className="text-white/90 text-lg mb-6">Captured, classified, routed, responded, tracked, and recorded.</p>
              <button
                onClick={stopAndResetSimulation}
                className="bg-white text-[#1C5A31] px-8 py-3 rounded-lg font-bold hover:scale-[1.01] transition-transform"
              >
                Run Again
              </button>
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-6 bg-[#1B1B1B]">
        <div className="max-w-5xl mx-auto bg-[#2D2D2D] rounded-2xl p-10 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">Want this wired to your business?</h2>
          <p className="text-[#D3AE8A] text-lg mb-7">
            MVP promise: fewer missed messages, faster follow-up, and a clean audit trail path.
          </p>
          <button
            onClick={() => addNotification("CTA clicked. Wire this to Calendly/Stripe next.", "success")}
            className="bg-gradient-to-r from-[#55A843] to-[#1C5A31] text-white px-8 py-3 rounded-xl font-bold hover:scale-[1.01] transition-transform inline-flex items-center justify-center"
          >
            Book a 15-min intro
            <ArrowRight className="ml-2" size={18} />
          </button>
        </div>
      </section>

      <footer className="py-10 px-6 bg-[#2D2D2D]">
        <div className="max-w-7xl mx-auto text-center text-[#D3AE8A] text-sm">
          Minimal, runnable MVP. Real data via user-pasted Reddit JSON (no automated scraping).
        </div>
      </footer>
    </div>
  );
}
