# SureLink (static, no-MITM, tamper-evident contact pages)

## What this is
- A generator that turns **verified provider endpoints** into **immutable** static pages:
  - `/p/<slug>/h/<sha256>/`
- A stable convenience URL:
  - `/p/<slug>` → **redirect only** → latest hashed version
- No forms, no inbox, no user accounts, no payment handling.

## Quick start (local)
```bash
npm ci
npm run build
npx serve public -p 3000
```

Open:
- Immutable page: `http://localhost:3000/p/handyman-bob/h/<hash>/`
- Manifest: `http://localhost:3000/p/handyman-bob/h/<hash>/manifest.json`

Get the hash:
```bash
npm run print:hashes
```

## Local redirect parity (Vercel-like)
Install Vercel CLI:
```bash
npm i -g vercel
```

Run:
```bash
npm run build
vercel dev --listen 3000
```

Test:
- `http://localhost:3000/p/handyman-bob` should redirect to `/p/handyman-bob/h/<hash>/`

## Commands
- Build + write artifacts: `npm run build`
- Validate only (CI): `npm run check`
- Clean generated output: `npm run clean`
- Print slugs + hashes: `npm run print:hashes`
- Print redirects JSON: `npm run print:redirects`

## Security posture (baseline)
- CSP blocks scripts and external content by default.
- Pages are immutable by hash.
- Publish gate: listings require `phone_verified: true` (manual/OTP process external to this repo).

## Optional signing (Ed25519)
Set env vars before build:
- `SURELINK_SIGNING_PRIVATE_KEY` (PEM)
- `SURELINK_SIGNING_PUBLIC_KEY` (PEM)

Then re-run `npm run build`. A `manifest.sig` and `public/proof/pubkey.txt` will be emitted.

## Deploy to Vercel
- Import the repo into Vercel
- Build command: `npm run build`
- Output: `public`
- `vercel.json` is generated during the build (redirects + headers).
