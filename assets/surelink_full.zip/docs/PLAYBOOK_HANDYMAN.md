# Handyman thread posting playbook (2025/26)

## Goal
Convert referral-thread intent (Nextdoor/Facebook/Reddit) into **direct calls/bookings** without DMs.

## One rule
Post only as a reply to a real request. Frame as contact info, not promotion.

## Templates
### Facebook / Nextdoor
- "I’m local and can help. Call or book me here: https://<domain>/p/<slug>"

### Reddit (add value first)
- "Before patching drywall, confirm there's no moisture source. If you're local, reach me here: https://<domain>/p/<slug>"

## Do not
- Bulk post, automate replies, or cross-post aggressively
- Use urgency/discount language
- Claim "verified", "licensed", "insured" unless requested and verifiable

## If questioned
- "This is just my phone and booking info so neighbors can reach me without DMs."
