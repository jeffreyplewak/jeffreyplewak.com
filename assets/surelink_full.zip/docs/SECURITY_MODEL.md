# Security model (no-MITM + tamper-evidence)

## Invariants
- No forms that post to your backend
- No inbox or relay
- No payment processing by you
- All CTAs are direct links: tel:, mailto:, booking provider, payment provider
- Slug URL is redirect-only; hash URL is immutable

## Tamper-evidence
- Canonical manifest.json -> SHA-256 -> used in URL path /h/<hash>/
- Any change produces a new hash and new immutable URL

## Abuse prevention (baseline)
- Publish gate: phone_verified must be true
- Booking/payment domain allowlists
- Takedown channel (mailto) + operational process

## Optional authenticity
- Ed25519 signature for manifest using Node crypto (environment keys)
