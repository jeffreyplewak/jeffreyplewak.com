# Troubleshooting

## Build fails: schema validation
- Inspect: data/listings.json
- Ensure required fields and phone_verified=true

## Build fails: host not allowed
- Update data/allowlists.json or use an allowlisted provider domain.

## Redirect doesn't work locally
- Redirects are Vercel behavior (vercel.json).
- Use: vercel dev --listen 3000

## Hash mismatch
- Do not hand-edit generated manifests under public/p/.
- Re-run: npm run clean && npm run build
