#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-3000}"

RED=$'\033[0;31m'
GRN=$'\033[0;32m'
YLW=$'\033[1;33m'
BLU=$'\033[0;34m'
RST=$'\033[0m'

say()  { printf "%s\n" "$*"; }
info() { printf "%s\n" "${BLU}INFO${RST}: $*"; }
warn() { printf "%s\n" "${YLW}WARN${RST}: $*"; }
ok()   { printf "%s\n" "${GRN}OK${RST}: $*"; }
die()  { printf "%s\n" "${RED}FAIL${RST}: $*"; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"; }
require_file() { [[ -f "$1" ]] || die "Missing required file: $1"; }
require_dir() { [[ -d "$1" ]] || die "Missing required directory: $1"; }

headline() {
  say ""
  say "============================================================"
  say "$1"
  say "============================================================"
}

kill_on_exit() {
  local pid="$1"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" >/dev/null 2>&1; then
    warn "Stopping local server (pid=$pid)"
    kill "$pid" >/dev/null 2>&1 || true
  fi
}

headline "0) Environment checks (macOS / Apple Silicon / 2026-safe baseline)"
cd "$REPO_ROOT"

need_cmd bash
need_cmd node
need_cmd npm

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$NODE_MAJOR" -lt 18 ]]; then
  die "Node >= 18 required. You have: $(node -v). Install Node 20 LTS."
fi
ok "Node version: $(node -v)"
ok "npm version:  $(npm -v)"

require_file "package.json"
require_file "scripts/build.mjs"
require_file "data/listings.json"
require_file "data/listings.schema.json"
require_file "data/allowlists.json"
require_dir  "public"
require_dir  "public/assets"
require_file "public/assets/style.css"
ok "Repo structure looks intact."

headline "1) Dependency install (deterministic)"
if [[ -f package-lock.json ]]; then
  info "package-lock.json found -> using npm ci"
  npm ci
else
  warn "package-lock.json not found -> using npm install (commit a lockfile for maximum determinism)"
  npm install
fi
ok "Dependencies installed."

headline "2) Validate inputs (schema + allowlists) without generating output"
npm run check
ok "Input validation passed."

headline "3) Build static output (immutable pages + vercel.json)"
npm run build
ok "Build completed."

headline "4) Post-build verification (must exist or fail)"
require_dir "public/p" || die "public/p missing; build did not generate outputs."

FIRST_SLUG="$(node -e "const fs=require('fs'); const j=JSON.parse(fs.readFileSync('data/listings.json','utf8')); console.log(Object.keys(j)[0]||'');")"
[[ -n "$FIRST_SLUG" ]] || die "No listings found in data/listings.json"

HASH_DIR="public/p/${FIRST_SLUG}/h"
require_dir "$HASH_DIR"
FIRST_HASH="$(ls -1 "$HASH_DIR" | head -n 1 | tr -d '\r\n')"
[[ -n "$FIRST_HASH" ]] || die "No hash directory generated for slug: $FIRST_SLUG"

PAGE_DIR="public/p/${FIRST_SLUG}/h/${FIRST_HASH}"
require_dir "$PAGE_DIR"
require_file "$PAGE_DIR/index.html"
require_file "$PAGE_DIR/manifest.json"
require_file "$PAGE_DIR/manifest.sha256"

CALC_HASH="$(node -e "const fs=require('fs'); const crypto=require('crypto'); const b=fs.readFileSync('${PAGE_DIR}/manifest.json'); console.log(crypto.createHash('sha256').update(b).digest('hex'));")"
FILE_HASH="$(cat "$PAGE_DIR/manifest.sha256" | tr -d ' \r\n')"
[[ "$CALC_HASH" == "$FILE_HASH" ]] || die "Hash mismatch: computed=$CALC_HASH file=$FILE_HASH"

ok "Generated page verified for slug=${FIRST_SLUG} hash=${FIRST_HASH}"
ok "Tamper-evidence verified: manifest.json SHA-256 matches manifest.sha256"

headline "5) Localhost test server (static output)"
need_cmd npx

info "Starting static server on http://localhost:${PORT}"
set +e
npx serve public -p "$PORT" >/dev/null 2>&1 &
SERVE_PID=$!
set -e
trap "kill_on_exit $SERVE_PID" EXIT

sleep 1
if ! kill -0 "$SERVE_PID" >/dev/null 2>&1; then
  die "Local server failed to start."
fi
ok "Local server running (pid=${SERVE_PID})"

IMMUTABLE_URL="http://localhost:${PORT}/p/${FIRST_SLUG}/h/${FIRST_HASH}/"
MANIFEST_URL="http://localhost:${PORT}/p/${FIRST_SLUG}/h/${FIRST_HASH}/manifest.json"
SHA_URL="http://localhost:${PORT}/p/${FIRST_SLUG}/h/${FIRST_HASH}/manifest.sha256"

say ""
say "Open these now:"
say "  Immutable page:  ${IMMUTABLE_URL}"
say "  Manifest:        ${MANIFEST_URL}"
say "  SHA-256 proof:   ${SHA_URL}"
say ""
warn "Redirect testing note: /p/<slug> redirects are applied by Vercel using vercel.json."
warn "To test redirects locally: npm i -g vercel && vercel dev --listen ${PORT}"

headline "6) Next actions (prompted)"
say "Choose the next step:"
say "  1) Replace demo endpoints with real verified endpoints"
say "  2) Deploy to Vercel (production) and test redirects + headers"
say "  3) Post a ToS-safe reply in a real thread (validate conversion)"
say ""

read -r -p "Enter 1 / 2 / 3: " CHOICE
case "${CHOICE}" in
  1)
    say ""
    info "Edit: data/listings.json"
    say "Hard rules:"
    say "  - phone must be E.164: +12525550123"
    say "  - set phone_verified=true only after OTP/call verification"
    say "  - booking/payment URLs must be https and allowlisted (data/allowlists.json)"
    say ""
    say "Then run:"
    say "  npm run check"
    say "  npm run build"
    ;;
  2)
    say ""
    info "Vercel deploy (recommended)"
    say "One-time:"
    say "  npm i -g vercel"
    say ""
    say "Then:"
    say "  vercel login"
    say "  vercel --prod"
    say ""
    say "After deploy, test:"
    say "  https://<your-domain>/p/${FIRST_SLUG}   (should redirect)"
    say "  https://<your-domain>/p/${FIRST_SLUG}/h/${FIRST_HASH}/"
    ;;
  3)
    say ""
    info "ToS-safe reply template (reply to a request; do not post as an ad)"
    say "Facebook/Nextdoor:"
    say "  "I’m local and can help. Call or book me here: https://<your-domain>/p/${FIRST_SLUG}""
    say ""
    say "Reddit (add value first):"
    say "  "For this job, confirm X before repair. If you're local, reach me here: https://<your-domain>/p/${FIRST_SLUG}""
    ;;
  *)
    die "Invalid choice."
    ;;
esac

headline "7) Verification checklist (must pass before 'works' claim)"
say "Local:"
say "  - Page loads, buttons correct"
say "  - Manifest + sha256 reachable"
say "  - No scripts, no forms, no tracking"
say ""
say "Production (Vercel):"
say "  - /p/${FIRST_SLUG} redirects to /p/${FIRST_SLUG}/h/<hash>/"
say "  - Security headers present (CSP, HSTS, etc.)"
say "  - Immutable page and proofs reachable"
say ""
ok "Done. Server stays up until you Ctrl+C."
wait
