import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { canonicalize } from "json-canonicalize";
import Ajv from "ajv";
import http from "node:http";

const ROOT = process.cwd();
const DATA_DIR = path.join(ROOT, "data");
const PUBLIC_DIR = path.join(ROOT, "public");

const LISTINGS_PATH = path.join(DATA_DIR, "listings.json");
const SCHEMA_PATH = path.join(DATA_DIR, "listings.schema.json");
const ALLOWLISTS_PATH = path.join(DATA_DIR, "allowlists.json");

const OUT_P_DIR = path.join(PUBLIC_DIR, "p");
const OUT_PROOF_DIR = path.join(PUBLIC_DIR, "proof");
const STYLE_PATH = "/assets/style.css";

const args = new Set(process.argv.slice(2));
const FLAGS = {
  ci: args.has("--ci"),
  checkOnly: args.has("--check-only"),
  writeHtml: args.has("--write-html"),
  writeVercel: args.has("--write-vercel"),
  clean: args.has("--clean"),
  serve: args.has("--serve"),
  checkLinks: args.has("--check-links"),
  debug: args.has("--debug"),
  verbose: args.has("--verbose") || args.has("--ci"),
  printHashes: args.has("--print-hashes"),
  printRedirects: args.has("--print-redirects"),
};

function nowIso() {
  return new Date().toISOString();
}

function log(...m) { if (FLAGS.verbose) console.log(...m); }
function warn(...m) { console.warn(...m); }

function die(message, details = []) {
  console.error("BUILD FAILED:", message);
  if (details.length) {
    console.error("DETAILS:");
    for (const d of details) console.error(" -", d);
  }
  if (FLAGS.debug) console.error("DEBUG: enable --debug for stack traces already on.");
  process.exit(1);
}

function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }

function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, "utf8")); }
  catch (e) { die(`Could not read JSON: ${p}`, [String(e)]); }
}

function rmrf(p) {
  if (!exists(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}

function sha256Hex(bytes) {
  return crypto.createHash("sha256").update(bytes).digest("hex");
}

function isHttpsUrl(u) {
  try {
    const x = new URL(u);
    return x.protocol === "https:";
  } catch {
    return false;
  }
}

function hostOf(u) {
  return new URL(u).host.toLowerCase();
}

function hostAllowed(host, allowlist) {
  return allowlist.some((x) => host === x || host.endsWith(`.${x}`));
}

function validateEmailLoose(email) {
  if (email == null) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function safeText(s) {
  return String(s ?? "").replace(/[<>]/g, "");
}

function maybeWritePubkey() {
  const pub = process.env.SURELINK_SIGNING_PUBLIC_KEY?.trim();
  if (!pub) return;
  ensureDir(OUT_PROOF_DIR);
  fs.writeFileSync(path.join(OUT_PROOF_DIR, "pubkey.txt"), pub + "\n", "utf8");
}

function maybeSignEd25519(bytes) {
  const pem = process.env.SURELINK_SIGNING_PRIVATE_KEY?.trim();
  if (!pem) return null;
  try {
    const keyObj = crypto.createPrivateKey(pem);
    const sig = crypto.sign(null, bytes, keyObj); // Ed25519 when key is Ed25519
    return sig.toString("base64");
  } catch (e) {
    die("Signing failed. Ensure your key is valid Ed25519 PEM.", [String(e)]);
  }
}

function renderHtml({ title, subtitle, actionsHtml, extraHtml, hash }) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${safeText(title)}</title>
  <meta name="description" content="${safeText(subtitle || `Contact ${title}`)}" />
  <link rel="stylesheet" href="${STYLE_PATH}" />
  <meta name="robots" content="index,follow" />
</head>
<body>
  <main class="wrap">
    <header class="card">
      <h1>${safeText(title)}</h1>
      ${subtitle ? `<p class="sub">${safeText(subtitle)}</p>` : ""}
    </header>

    <section class="card">
      <div class="actions">
        ${actionsHtml}
      </div>
      ${extraHtml || ""}
    </section>

    <footer class="card foot">
      <p class="small">
        This page connects you directly to the business listed above. All services and transactions are handled by the business.
      </p>
      <p class="small">
        Content hash: <code>${hash.slice(0, 12)}…</code>
      </p>
      <div class="proof">
        <a class="link" href="./manifest.json">View manifest</a>
        <a class="link" href="./manifest.sha256">SHA-256</a>
        ${exists(path.join(OUT_PROOF_DIR, "pubkey.txt")) ? `<a class="link" href="/proof/pubkey.txt">Public key</a>` : ""}
        ${exists("./manifest.sig") ? `<a class="link" href="./manifest.sig">Signature</a>` : ""}
      </div>
      <p class="small">
        Report a listing: <a class="link" href="mailto:plewak.jeff@gmail.com?subject=Report%20listing">email</a>
      </p>
    </footer>
  </main>
</body>
</html>`;
}

async function headOk(url, timeoutMs = 4500) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "HEAD", redirect: "follow", signal: ctrl.signal });
    return { ok: res.ok, status: res.status };
  } catch (e) {
    return { ok: false, status: 0, error: String(e) };
  } finally {
    clearTimeout(t);
  }
}

function writeVercelJson(redirects) {
  const headers = [
    {
      source: "/(.*)",
      headers: [
        { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains; preload" },
        { key: "X-Content-Type-Options", value: "nosniff" },
        { key: "X-Frame-Options", value: "DENY" },
        { key: "Referrer-Policy", value: "no-referrer" },
        { key: "Permissions-Policy", value: "geolocation=(), microphone=(), camera=()" },
        {
          key: "Content-Security-Policy",
          value: [
            "default-src 'none'",
            "style-src 'self'",
            "img-src 'self' data:",
            "font-src 'self'",
            "connect-src 'none'",
            "frame-ancestors 'none'",
            "base-uri 'none'",
            "form-action 'none'",
            "upgrade-insecure-requests"
          ].join("; ")
        }
      ]
    }
  ];

  const vercelJson = { version: 2, cleanUrls: true, redirects, headers };
  fs.writeFileSync(path.join(ROOT, "vercel.json"), JSON.stringify(vercelJson, null, 2) + "\n", "utf8");
}

function listFirstHashFor(slug) {
  const dir = path.join(OUT_P_DIR, slug, "h");
  if (!exists(dir)) return null;
  const entries = fs.readdirSync(dir).filter(Boolean);
  return entries.length ? entries[0] : null;
}

function startStaticServer(port = 3000) {
  // Minimal static server for public/ (debug-friendly). No redirects; use vercel dev for that.
  const base = PUBLIC_DIR;
  const server = http.createServer((req, res) => {
    try {
      const u = new URL(req.url, `http://localhost:${port}`);
      let p = decodeURIComponent(u.pathname);
      if (p.endsWith("/")) p += "index.html";
      const fsPath = path.join(base, p);
      if (!fsPath.startsWith(base)) {
        res.writeHead(400); res.end("Bad request"); return;
      }
      if (!exists(fsPath)) {
        res.writeHead(404); res.end("Not found"); return;
      }
      const ext = path.extname(fsPath).toLowerCase();
      const ct = ext === ".html" ? "text/html; charset=utf-8"
               : ext === ".json" ? "application/json; charset=utf-8"
               : ext === ".css" ? "text/css; charset=utf-8"
               : ext === ".txt" ? "text/plain; charset=utf-8"
               : "application/octet-stream";
      res.writeHead(200, { "Content-Type": ct });
      res.end(fs.readFileSync(fsPath));
    } catch (e) {
      res.writeHead(500);
      res.end("Server error");
    }
  });
  server.listen(port, () => {
    console.log(`Local static server: http://localhost:${port}`);
    console.log("Note: redirects are not applied here. Use: vercel dev --listen 3000");
  });
}

async function main() {
  if (FLAGS.clean) {
    rmrf(path.join(PUBLIC_DIR, "p"));
    if (exists(path.join(ROOT, "vercel.json"))) fs.rmSync(path.join(ROOT, "vercel.json"), { force: true });
    console.log("OK: cleaned generated output (public/p, vercel.json)");
    return;
  }

  const allowlists = readJson(ALLOWLISTS_PATH);
  const listings = readJson(LISTINGS_PATH);
  const schema = readJson(SCHEMA_PATH);

  // Schema validation
  const ajv = new Ajv({ allErrors: true, allowUnionTypes: true, strict: true });
  const validate = ajv.compile(schema);
  const ok = validate(listings);
  if (!ok) {
    die("Schema validation failed.", [ajv.errorsText(validate.errors, { separator: "\n" })]);
  }

  // Additional security/UX gates + optional link checks
  const errors = [];
  const redirects = [];
  const hashes = {};

  ensureDir(OUT_P_DIR);
  maybeWritePubkey();

  for (const [slug, cfg] of Object.entries(listings)) {
    const ctx = `"${slug}"`;

    if (cfg.email && !validateEmailLoose(cfg.email)) errors.push(`${ctx} email looks invalid.`);
    if (cfg.booking_url) {
      if (!isHttpsUrl(cfg.booking_url)) errors.push(`${ctx} booking_url must be https.`);
      else {
        const h = hostOf(cfg.booking_url);
        if (!hostAllowed(h, allowlists.booking_hosts)) errors.push(`${ctx} booking_url host not allowed: ${h}`);
      }
    }
    if (cfg.stripe_checkout_url) {
      if (!isHttpsUrl(cfg.stripe_checkout_url)) errors.push(`${ctx} stripe_checkout_url must be https.`);
      else {
        const h = hostOf(cfg.stripe_checkout_url);
        if (!hostAllowed(h, allowlists.payment_hosts)) errors.push(`${ctx} stripe_checkout_url host not allowed: ${h}`);
      }
    }
    if (cfg.google_maps_url) {
      if (!isHttpsUrl(cfg.google_maps_url)) errors.push(`${ctx} google_maps_url must be https.`);
      else {
        const h = hostOf(cfg.google_maps_url);
        if (!hostAllowed(h, allowlists.maps_hosts)) warn(`WARN: ${ctx} maps host not in allowlist: ${h}`);
      }
    }

    // Canonical manifest (proof object)
    const manifest = {
      slug,
      published_at: nowIso(),
      published_by: cfg.published_by ?? null,
      vertical: cfg.vertical,
      endpoints: {
        tel: cfg.phone,
        email: cfg.email ?? null,
        booking: cfg.booking_url ?? null,
        maps: cfg.google_maps_url ?? null,
        payment: cfg.stripe_checkout_url ?? null
      }
    };

    const canonical = canonicalize(manifest);
    const bytes = Buffer.from(canonical, "utf8");
    const hash = sha256Hex(bytes);
    hashes[slug] = hash;

    if (FLAGS.writeHtml) {
      const outDir = path.join(OUT_P_DIR, slug, "h", hash);
      ensureDir(outDir);

      fs.writeFileSync(path.join(outDir, "manifest.json"), canonical + "\n", "utf8");
      fs.writeFileSync(path.join(outDir, "manifest.sha256"), hash + "\n", "utf8");

      const sig = maybeSignEd25519(bytes);
      if (sig) fs.writeFileSync(path.join(outDir, "manifest.sig"), sig + "\n", "utf8");

      // Actions: keep simple (2 primaries)
      const title = cfg.name;
      const subtitle = [cfg.service, cfg.area].filter(Boolean).join(" · ");

      const actions = [];
      if (cfg.phone) actions.push(`<a class="btn primary" href="tel:${safeText(cfg.phone)}" aria-label="Call ${safeText(title)}">Call</a>`);
      if (cfg.booking_url) actions.push(`<a class="btn primary" href="${safeText(cfg.booking_url)}" rel="noopener noreferrer" aria-label="Book with ${safeText(title)}">Book</a>`);
      if (cfg.email) actions.push(`<a class="btn" href="mailto:${safeText(cfg.email)}" aria-label="Email ${safeText(title)}">Email</a>`);

      let extra = "";
      if (cfg.google_maps_url) extra += `<p class="note"><a class="link" href="${safeText(cfg.google_maps_url)}" rel="noopener noreferrer">View on Google Maps</a></p>`;
      if (cfg.stripe_checkout_url) {
        extra += `<p class="note">Payments (if used) are processed directly by the business.</p>
<a class="btn subtle" href="${safeText(cfg.stripe_checkout_url)}" rel="noopener noreferrer" aria-label="Optional deposit (processed by the business)">Optional deposit</a>`;
      }

      const html = renderHtml({ title, subtitle, actionsHtml: actions.join("\n"), extraHtml: extra, hash });
      fs.writeFileSync(path.join(outDir, "index.html"), html, "utf8");
    }

    redirects.push({ source: `/p/${slug}`, destination: `/p/${slug}/h/${hash}/`, permanent: false });
    redirects.push({ source: `/p/${slug}/`, destination: `/p/${slug}/h/${hash}/`, permanent: false });

    if (FLAGS.checkLinks) {
      const checks = [];
      if (cfg.booking_url) checks.push({ kind: "booking_url", url: cfg.booking_url });
      if (cfg.stripe_checkout_url) checks.push({ kind: "stripe_checkout_url", url: cfg.stripe_checkout_url });
      if (cfg.google_maps_url) checks.push({ kind: "google_maps_url", url: cfg.google_maps_url });

      for (const c of checks) {
        const r = await headOk(c.url);
        if (!r.ok) {
          errors.push(`${ctx} ${c.kind} not reachable (HEAD). status=${r.status}${r.error ? ` err=${r.error}` : ""}`);
        }
      }
    }
  }

  if (errors.length) die("Validation gates failed.", errors);

  if (FLAGS.printHashes) {
    console.log(JSON.stringify(hashes, null, 2));
    return;
  }
  if (FLAGS.printRedirects) {
    console.log(JSON.stringify(redirects, null, 2));
    return;
  }

  if (FLAGS.writeVercel) writeVercelJson(redirects);

  if (FLAGS.checkOnly) {
    console.log("OK: check-only passed.");
    return;
  }

  console.log(`OK: generated ${Object.keys(hashes).length} listing(s).`);
  if (FLAGS.verbose) {
    for (const [slug, hash] of Object.entries(hashes)) {
      console.log(` - ${slug}: /p/${slug}/h/${hash}/`);
    }
    if (FLAGS.writeVercel) console.log(" - vercel.json written (redirects + headers)");
  }

  if (FLAGS.serve) startStaticServer(3000);
}

main().catch((e) => {
  if (FLAGS.debug) console.error(e);
  die("Unhandled error.", [String(e)]);
});
